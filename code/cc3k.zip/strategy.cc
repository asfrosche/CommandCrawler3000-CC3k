#include "strategy.h"

Strategy::~Strategy() {}
