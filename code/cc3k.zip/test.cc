#include <iostream>

int main() {
    printf("\033[1;31m text\n");
}