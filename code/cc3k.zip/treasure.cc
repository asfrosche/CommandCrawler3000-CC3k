#include "treasure.h"

class Dragon;

Treasure::Treasure(int value, int x, int y): Piece{'G', x, y}, value{value} {}

int Treasure::getValue() const { return value; }

void Treasure::changeGuard(std::shared_ptr<Dragon> d) {
    guard = d;
}

std::shared_ptr<Dragon> Treasure::getGuard() {
    return guard;
}
