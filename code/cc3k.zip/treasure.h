#ifndef _TREASURE_H_
#define _TREASURE_H_
#include "piece.h"
#include "dragon.h"
#include <memory>

class Treasure: public Piece {
    int value;
    std::shared_ptr<Dragon> guard;
  public:
    Treasure(int value, int x, int y);
    int getValue() const;
    std::shared_ptr<Dragon> getGuard();
    void changeGuard(std::shared_ptr<Dragon> d);
};

#endif
