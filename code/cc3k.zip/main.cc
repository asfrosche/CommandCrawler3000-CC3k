#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include "board.h"
using namespace std;
 
int main(int argc, char* argv[]) {
    bool fileIncluded = false;
    string theFile = "";
    if (argc > 1) {
        for (int i = 0; i < argc; ++i) {
            if (atoi(argv[i]) != 0) { 
                srand(atoi(argv[i])); 
            } else {
                ifstream file;
                file.open(argv[i], ios::in);
                if (!file) {
                    cout << "Invalid command line arguments. yeah" << endl;
                    return 0;
                } else {
                    fileIncluded = true;
                    theFile = argv[i];
                }
            }
        }
    }
    Board b{fileIncluded, theFile};
    bool done = false;
    while (!done) {
        done = b.playGame();
    }
}
