#ifndef SHADE_H
#define SHADE_H
#include "../race.h"

class Shade: public Race {
 public:
    Shade(int x, int y);
    virtual ~Shade();
};

#endif
