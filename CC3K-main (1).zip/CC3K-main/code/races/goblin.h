#ifndef GOBLIN_H
#define GOBLIN_H
#include "../race.h"

class Goblin: public Race {
 public:
    Goblin(int x, int y);
    virtual ~Goblin();
};

#endif
