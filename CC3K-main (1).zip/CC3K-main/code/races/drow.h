#ifndef DROW_H
#define DROW_H
#include "../race.h"

class Drow: public Race {
 public:
    Drow(int x, int y);
    virtual ~Drow();
};

#endif
