#include "merchantHoard.h"

MerchantHoard::MerchantHoard(int x, int y): Treasure{4, x, y} {}
