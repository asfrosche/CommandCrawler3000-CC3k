#include "smallPile.h"

SmallPile::SmallPile(int x, int y): Treasure{1, x, y} {}
