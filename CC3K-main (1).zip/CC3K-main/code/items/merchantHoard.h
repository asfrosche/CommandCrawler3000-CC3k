#ifndef MERCHANTHOARD_H
#define MERCHANTHOARD_H
#include "../treasure.h"

class MerchantHoard: public Treasure {
  public:
    MerchantHoard(int x, int y);
};

#endif
