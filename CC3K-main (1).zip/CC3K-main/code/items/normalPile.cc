#include "normalPile.h"

NormalPile::NormalPile(int x, int y): Treasure{2, x, y} {}
