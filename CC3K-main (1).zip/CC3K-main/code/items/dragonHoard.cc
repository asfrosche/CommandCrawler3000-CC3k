#include "dragonHoard.h"
#include "../dragon.h"

DragonHoard::DragonHoard(int x, int y): Treasure{6, x, y} {}

