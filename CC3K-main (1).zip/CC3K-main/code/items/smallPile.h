#ifndef _SMALLPILE_H_
#define _SMALLPILE_H_
#include "../treasure.h"

class SmallPile: public Treasure {public:
    SmallPile(int x, int y);
};

#endif
