#ifndef NORMALPILE_H
#define NORMALPILE_H
#include "../treasure.h"

class NormalPile: public Treasure {
  public:
    NormalPile(int x, int y);
};
 
#endif
