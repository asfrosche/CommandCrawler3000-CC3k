#include "human.h"

Human::Human(int x, int y) : Enemy{140, 20, 20, 0, 'H', x, y} {}

Human::~Human() {}
