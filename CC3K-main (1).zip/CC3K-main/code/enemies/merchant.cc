#include "merchant.h"

Merchant::Merchant(int x, int y) : Enemy{30, 70, 5, 0, 'M', x, y} {}

Merchant::~Merchant() {} 
