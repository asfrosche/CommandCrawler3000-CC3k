#include "dwarf.h"

Dwarf::Dwarf(int x, int y) : Enemy{100, 20, 30, randomGold(), 'W', x, y} {}

Dwarf::~Dwarf() {}
