#include "orc.h"

// #include <cmath>
// #include <stdio.h>
// #include <stdlib.h>
// #include <time.h>

Orc::Orc(int x, int y) : Enemy{180, 30, 10, randomGold(), 'O', x, y} {}

Orc::~Orc() {} 
