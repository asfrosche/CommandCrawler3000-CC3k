# CommandCrawler3000 (CC3K)
This game is a simplified rougue-like created as a final project for CS246 - an Object-Oriented Software Development course at the University of Waterloo. 
It was written in C++ and utilises Encapsulation, Inheritance, Abstraction and Polymorphism and makes use of the Stategy design pattern.
#### Objective:
The objective of the game is to make it through the chambers and passages and to reach the stair on the floor to make it up all the way to the fifth floor. The player wins by reaching the final stair on the fifth floor. There are enemies moving about within the chambers that will attack you if they see you and there are unknown potions that you may find and utilize.
#### Note:
It was written in part by Cecilia Qiu, Lisa Huynh and Aryan Sureka and the question specifications and instructions outlined by given game specifications and design requirements.
